import { Imagen } from './imagen';

describe('Imagen', () => {
  it('should create an instance', () => {
    expect(new Imagen()).toBeTruthy();
  });
});
