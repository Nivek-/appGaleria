export class Imagen {
  constructor(
    public id: string,
    public nombre: string,
    public descripcion: string,
    public miniatura: string,
    public enlace: string
  ) {}
}
