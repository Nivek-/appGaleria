import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'unab-menusuperior',
  templateUrl: './menusuperior.component.html',
  styles: ['h1 { font-weight: normal; }']
})
export class MenusuperiorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
